import sys
from numpy import loadtxt
import numpy as np
from sklearn import datasets
import pylab as plt
from sklearn.manifold import TSNE
import random
from sklearn import metrics

def fill_labels(data,k,maxiter=100):
    clusters = [data[int(random.random()*len(data))] for i in range(k)]
    labels = []
    for i in range(maxiter):
		labels = []
		for j in range(len(data)):
			labels_array = []
			for index in range(k):
				labels_array.append(np.dot(data[j]-clusters[index], data[j]-clusters[index])**2)
			labels.append(np.argmin(np.array(labels_array)))
    return labels


def fill_clusters(data,k,labels,maxiter=100):
    clusters = []
    for j in range(k):
		clusters_array = []
		for index in range(len(data)):
			if(labels[index]==j):
				clusters_array.append(data[index])
		mean = np.mean(clusters_array, axis = 0)
		flag = []
		for n in range(len(clusters_array)):
			flag.append(np.dot(clusters_array[n]-mean, clusters_array[n]-mean)**2)
		clusters.append(clusters_array[np.argmin(flag)])
    return clusters


def Kmean(data, k, maxiter=100):
    labels=fill_labels(data,k)
    clusters=fill_clusters(data,k,labels)
    return clusters, labels

#####################################################################################

#IRIS DATASET

iris = datasets.load_iris()
X = iris.data
y_labels = iris.target

tsne=TSNE(n_components=2).fit_transform(X)

x_coordinates=tsne[:,0]
y_coordinates=tsne[:,1]

plt.scatter(x_coordinates,y_coordinates,c=['b','g','r'])
plt.title('IRIS Before Kmeans')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.show()


clusters, y = Kmean(X, 3)


plt.scatter(x_coordinates, y_coordinates, c=y, cmap=plt.cm.Paired)
plt.title('IRIS After Kmeans')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.show()

ari = metrics.adjusted_rand_score(y_labels, y)
print "ARI of IRIS:", ari
nmi = metrics.cluster.normalized_mutual_info_score(y_labels, y)
print "NMI of IRIS:", nmi
ami = metrics.cluster.adjusted_mutual_info_score(y_labels, y)
print "AMI of IRIS:", ami

#####################################################################################

#SEEDS DATASET


X = loadtxt('./Data/seeds_dataset.txt', delimiter='\t', unpack=False)

y_labels = X[:,-1]
X = X[:,:-1]

tsne=TSNE(n_components=2).fit_transform(X)

x_coordinates=tsne[:,0]
y_coordinates=tsne[:,1]

plt.scatter(x_coordinates,y_coordinates,c=['b','g','r'])
plt.title('SEEDS before Kmeans')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.show()


C, y = Kmean(X, 3)



plt.scatter(x_coordinates, y_coordinates, c=y, cmap=plt.cm.Paired)
plt.title('SEEDS after Kmeans')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.show()

ari = metrics.adjusted_rand_score(y_labels, y)
print "ARI of SEEDS:", ari
nmi = metrics.cluster.normalized_mutual_info_score(y_labels, y)
print "NMI of SEEDS:", nmi
ami = metrics.cluster.adjusted_mutual_info_score(y_labels, y)
print "AMI of SEEDS:", ami

#####################################################################################

# VERTEBRAL DATASET



X = loadtxt('./Data/vert.dat', delimiter=' ', unpack=False, dtype= 'str')

y_labels = X[:,-1]
X = X[:,:-1]
X.tolist()

X = [list(map(float, X[i])) for i in range(len(X))]
X = np.array(X)

for i in range(len(y_labels)):
	if(y_labels[i]=='DH'):
		y_labels[i] =0
	elif(y_labels[i]=='NO'):
		y_labels[i] =1
	elif(y_labels[i]=='SL'):
		y_labels[i] =2


tsne=TSNE(n_components=2).fit_transform(X)

x_coordinates=tsne[:,0]
y_coordinates=tsne[:,1]

plt.scatter(x_coordinates,y_coordinates,c=['b','g','r'])
plt.title('VERTEBRAL Before Kmeans')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.show()


C, y = Kmean(X, 3)


plt.scatter(x_coordinates, y_coordinates, c=y, cmap=plt.cm.Paired)
plt.title('VERTEBRAL After Kmeans')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.show()

ari = metrics.adjusted_rand_score(y_labels, y)
print "ARI of VERTEBRAL:", ari
nmi = metrics.cluster.normalized_mutual_info_score(y_labels, y)
print "NMI of VERTEBRAL:", nmi
ami = metrics.cluster.adjusted_mutual_info_score(y_labels, y)
print "AMI of VERTEBRAL:", ami

#####################################################################################

# SEGMENTATION DATASET


X = loadtxt('./Data/segmentation.data', delimiter=',', unpack=False, dtype = 'str')



y_labels = X[ :,0]
X = X[:,1:]
X.tolist()

X = [list(map(float, X[i])) for i in range(len(X))]
X = np.array(X)




for i in range(len(y_labels)):
	if(y_labels[i]=='SKY'):
		y_labels[i] =0
	elif(y_labels[i]=='BRICKFACE'):
		y_labels[i] =1
	elif(y_labels[i]=='FOLIAGE'):
		y_labels[i] =2
	elif(y_labels[i]=='CEMENT'):
		y_labels[i] =3
	elif(y_labels[i]=='WINDOW'):
		y_labels[i] =4
	elif(y_labels[i]=='PATH'):
		y_labels[i] =5
	elif(y_labels[i]=='GRASS'):
		y_labels[i] =6


tsne=TSNE(n_components=2).fit_transform(X)

x_coordinates=tsne[:,0]
y_coordinates=tsne[:,1]

plt.scatter(x_coordinates,y_coordinates,c=['b','g','r','c','m','y','k'])
plt.title('SEGMENTATION Before Kmeans')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.show()


C, y = Kmean(X, 7)

plt.scatter(x_coordinates, y_coordinates, c=y, cmap=plt.cm.Paired)
plt.title('SEGMENTATION After Kmeans')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.show()

ari = metrics.adjusted_rand_score(y_labels, y)
print "ARI of SEGMENTATION:", ari
nmi = metrics.cluster.normalized_mutual_info_score(y_labels, y)
print "NMI of SEGMENTATION:", nmi
ami = metrics.cluster.adjusted_mutual_info_score(y_labels, y)
print "AMI of SEGMENTATION:", ami
